package com.example.data.network

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object WolframAlphaClient {
    private const val TAG = "WolframAlphaClient"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    /**
     * Gets a short text answer from Wolfram Alpha Short Answer API.
     */
    suspend fun getShortAnswer(query: String, appId: String): String = withContext(Dispatchers.IO) {
        if (appId.isBlank()) {
            return@withContext "Wolfram Alpha App ID is not set. Please configure it in Settings."
        }

        val encodedQuery = try {
            URLEncoder.encode(query, "UTF-8")
        } catch (e: Exception) {
            query
        }

        val url = "https://api.wolframalpha.com/v1/result?appid=$appId&i=$encodedQuery"

        val request = Request.Builder()
            .url(url)
            .get()
            .build()

        try {
            okHttpClient.newCall(request).execute().use { response ->
                when (response.code) {
                    200 -> response.body?.string() ?: "No text output."
                    501 -> "Wolfram Alpha was unable to understand your query. Please check your syntax."
                    401 -> "Unauthorized App ID. Please verify your Wolfram Alpha App ID in Settings or Google AI Studio Secrets."
                    403 -> "Invalid App ID. Please verify your Wolfram Alpha App ID in Settings."
                    else -> "Wolfram Alpha returned an error: Code ${response.code}"
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching short answer", e)
            "Failed to reach Wolfram Alpha: ${e.localizedMessage}"
        }
    }

    /**
     * Returns the full URL for the Wolfram Alpha Simple API image.
     */
    fun getSimpleImageUrl(query: String, appId: String): String {
        val encodedQuery = try {
            URLEncoder.encode(query, "UTF-8")
        } catch (e: Exception) {
            query
        }
        // Custom background styling: background=F0F4F8 (very light gray/blue matching light mode)
        // or background=1E1E24 (dark charcoal matching dark mode)
        // We'll use transparent background or standard white/dark depending on preference.
        // Wolfram Simple API supports custom styling like: background=transparent or units=metric
        return "https://api.wolframalpha.com/v1/simple?appid=$appId&i=$encodedQuery&background=white&foreground=black&fontsize=14&units=metric"
    }
}
