package com.example.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface EquationDao {
    @Query("SELECT * FROM equation_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<EquationHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(equation: EquationHistory): Long

    @Query("DELETE FROM equation_history WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM equation_history")
    suspend fun clearAll()
}
