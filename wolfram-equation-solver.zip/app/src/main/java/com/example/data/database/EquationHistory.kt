package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "equation_history")
data class EquationHistory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val query: String,
    val engine: String, // "WOLFRAM", "GEMINI", "LOCAL"
    val resultText: String?,
    val resultImageUrl: String?,
    val timestamp: Long = System.currentTimeMillis()
)
