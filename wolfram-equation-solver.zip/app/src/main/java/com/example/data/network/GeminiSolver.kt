package com.example.data.network

import android.util.Log
import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

object GeminiSolver {
    private const val TAG = "GeminiSolver"
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    // Moshi JSON models for Gemini API
    data class Part(val text: String)
    data class Content(val parts: List<Part>)
    data class GenerateContentRequest(val contents: List<Content>, val systemInstruction: Content? = null)

    private suspend fun callGeminiWithFallback(prompt: String, systemInstruction: String): String = withContext(Dispatchers.IO) {
        var apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            // Keep the active Gemini API key as a fallback for external builds (e.g., zip exports)
            apiKey = "AQ.Ab8RN6KIaqp5kSGq3QbSLs8jAGIY3Yfj3bD80WIrI9aioqZWRw"
        }

        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "Gemini API Key is not set. Please add your key to the Secrets panel in AI Studio."
        }

        // Ordered list of candidate models for complex math/STEM/coding tasks.
        // gemini-3.1-pro-preview is highly accurate and suited for complex math and STEM.
        // gemini-3.5-flash and gemini-flash-latest act as reliable fallbacks.
        val candidateModels = listOf(
            "gemini-3.1-pro-preview",
            "gemini-3.5-flash",
            "gemini-flash-latest"
        )

        var lastErrorMsg = "No models attempted"

        for (model in candidateModels) {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
            Log.d(TAG, "Attempting call with model: $model")

            val requestObj = GenerateContentRequest(
                contents = listOf(Content(parts = listOf(Part(prompt)))),
                systemInstruction = Content(parts = listOf(Part(systemInstruction)))
            )

            val adapter = moshi.adapter(GenerateContentRequest::class.java)
            val requestJson = adapter.toJson(requestObj)

            val request = Request.Builder()
                .url(url)
                .post(requestJson.toRequestBody(jsonMediaType))
                .build()

            try {
                okHttpClient.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val responseBody = response.body?.string()
                        if (responseBody != null) {
                            Log.d(TAG, "Successfully generated content using model: $model")
                            return@withContext parseResponse(responseBody)
                        } else {
                            lastErrorMsg = "[$model] Received empty response body."
                        }
                    } else {
                        val errorBody = response.body?.string() ?: ""
                        Log.w(TAG, "Model $model failed with HTTP code ${response.code}: $errorBody")
                        lastErrorMsg = "[$model] Server returned code ${response.code}. ${errorBody.take(150)}"
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Exception during call with model $model", e)
                val exceptionName = e.javaClass.simpleName
                val message = e.localizedMessage ?: e.message ?: "Unknown network/IO error"
                lastErrorMsg = "[$model] $exceptionName: $message"
            }
        }

        return@withContext "All attempted Gemini models failed. Please verify your API key and network connection. Last error: $lastErrorMsg"
    }

    suspend fun solveEquation(equation: String): String {
        val prompt = """
            You are an expert mathematical assistant. Solve the following mathematical equation or expression step-by-step.
            Equation: $equation
            
            Format your response beautifully and clearly:
            1. **Problem Statement**: Restate the problem.
            2. **Step-by-step Solution**: Detail each algebraic step, explaining what you are doing. Use Unicode mathematical symbols (e.g. ², ³, √, ±, ≠, ∫, ∂, θ, π) for readability.
            3. **Final Result**: Boldly state the final solutions.
            4. **Plot Details**: If this equation can be plotted (e.g., function of x or relationship), describe the shape, roots, intercepts, and extrema to help the user visualize it.
            
            Keep the tone clear, academic, and encouraging.
        """.trimIndent()

        return callGeminiWithFallback(prompt, "You are a specialized mathematical tutor.")
    }

    suspend fun generateManimScript(equation: String): String {
        val prompt = """
            You are an expert mathematical animator and Python developer. Generate a complete, elegant, and bug-free Python script using the Manim CE (Community Edition) library to create an informative and beautiful mathematical animation illustrating: $equation.
            
            **CRITICAL TIMING RULE:**
            The animation must be exactly 15 seconds long. A short 3 to 5-second animation is a critical failure. You must include a structured sequence of actions, transitions, and wait times in your script that sum to exactly 15 seconds of play and wait commands.
            
            Use this exact duration budget in your code:
            1. **Title/Intro Sequence (3.0s total):**
               - Write title/text: `self.play(Write(title), run_time=2.0)`
               - Pause/Wait: `self.wait(1.0)`
            2. **Equation/Concept Presentation (4.0s total):**
               - Write formula: `self.play(Write(formula), run_time=2.5)`
               - Pause/Wait: `self.wait(1.5)`
            3. **Transformation / Step-by-Step Explanation (5.0s total):**
               - Transform or explain: `self.play(Transform(formula, step1), run_time=3.0)`
               - Pause/Wait: `self.wait(2.0)`
            4. **Outro & Conclusion (3.0s total):**
               - Draw frame/display final answer: `self.play(Create(box), run_time=1.5)`
               - Pause/Wait: `self.wait(1.5)`
            
            Sum of run_times and wait times must equal exactly 15.0 seconds. Ensure all `run_time` values are explicitly specified on every single `self.play` call, and use `self.wait` to fill the remaining time. Do not use default run_times.
            
            Structure your response into three clear sections:
            1. **Animation Concept**: A short description of how the animation visually demonstrates the mathematical concept over its 15-second duration.
            2. **Python Code**: The complete, copyable Python code inside standard ```python and ``` formatting. Ensure the class inherits from `Scene` (e.g., `class MathAnimation(Scene):`). Use modern Manim CE syntax, elegant styling (cyberpunk colors, neon accents like cyan, magenta, and yellow), and clear math text labels (using MathTex). You MUST explicitly specify `run_time` on every `self.play` call so the total sum is exactly 15 seconds.
            3. **Quick Guide**: Simple instructions for running it (local setup or a one-click Google Colab environment).
            
            Ensure the generated Python script is robust, correct, and self-contained so that a user can run it immediately without errors.
        """.trimIndent()

        return callGeminiWithFallback(prompt, "You are a specialized mathematical animator who generates beautiful animations. You MUST ensure the Python Manim script's play and wait commands total exactly 15 seconds of animation runtime. Short animations of 5 seconds or less are strictly prohibited.")
    }

    private fun parseResponse(jsonStr: String): String {
        return try {
            val jsonMap = moshi.adapter(Map::class.java).fromJson(jsonStr) as? Map<*, *>
            val candidates = jsonMap?.get("candidates") as? List<*>
            val candidate = candidates?.firstOrNull() as? Map<*, *>
            val content = candidate?.get("content") as? Map<*, *>
            val parts = content?.get("parts") as? List<*>
            val part = parts?.firstOrNull() as? Map<*, *>
            val text = part?.get("text") as? String
            text ?: "Could not parse response text from Gemini API."
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing response JSON", e)
            "Error parsing Gemini response: ${e.localizedMessage}"
        }
    }
}
