package com.example.data.plotter

import kotlin.math.*

class LocalPlotter(private val expression: String) {

    /**
     * Cleans the expression to be suitable for parsing in terms of x.
     */
    private val cleanedExpression: String = run {
        var expr = expression.trim()
        
        // Remove "y =" or "f(x) =" prefix if present
        if (expr.startsWith("y =", ignoreCase = true)) {
            expr = expr.substring(3)
        } else if (expr.startsWith("f(x) =", ignoreCase = true)) {
            expr = expr.substring(6)
        } else if (expr.contains("=")) {
            // e.g. "x^2 - 4x + 3 = 0" -> we can rearrange to "x^2 - 4x + 3"
            val parts = expr.split("=")
            if (parts.size == 2) {
                val left = parts[0].trim()
                val right = parts[1].trim()
                if (right == "0") {
                    expr = left
                } else {
                    expr = "($left) - ($right)"
                }
            }
        }
        
        expr
    }

    /**
     * Evaluates the function f(x) for a given value of x.
     * Returns Double.NaN if the calculation is invalid or undefined.
     */
    fun evaluate(x: Double): Double {
        return try {
            Parser(cleanedExpression, x).parse()
        } catch (e: Exception) {
            Double.NaN
        }
    }

    private class Parser(val str: String, val xVal: Double) {
        private var pos = -1
        private var ch = 0

        private fun nextChar() {
            ch = if (++pos < str.length) str[pos].code else -1
        }

        private fun eat(charToEat: Int): Boolean {
            while (ch == ' '.code) nextChar()
            if (ch == charToEat) {
                nextChar()
                return true
            }
            return false
        }

        fun parse(): Double {
            nextChar()
            val x = parseExpression()
            if (pos < str.length) {
                // If there are leftover characters, let's check if it's trailing whitespace
                while (pos < str.length && str[pos] == ' ') pos++
                if (pos < str.length) {
                    throw RuntimeException("Unexpected: " + str[pos])
                }
            }
            return x
        }

        private fun parseExpression(): Double {
            var x = parseTerm()
            while (true) {
                if (eat('+'.code)) x += parseTerm() // addition
                else if (eat('-'.code)) x -= parseTerm() // subtraction
                else break
            }
            return x
        }

        private fun parseTerm(): Double {
            var x = parseFactor()
            while (true) {
                if (eat('*'.code)) x *= parseFactor() // multiplication
                else if (eat('/'.code)) {
                    val divisor = parseFactor()
                    x = if (divisor == 0.0) Double.NaN else x / divisor // division
                }
                // Implicit multiplication support (e.g. "2x" or "3(x-2)")
                else if (isImplicitMultStart()) {
                    x *= parseFactor()
                } else {
                    break
                }
            }
            return x
        }

        private fun isImplicitMultStart(): Boolean {
            var tempPos = pos
            while (tempPos < str.length && str[tempPos] == ' ') {
                tempPos++
            }
            if (tempPos >= str.length) return false
            val nextCh = str[tempPos]
            return nextCh == 'x' || nextCh == '(' || nextCh.isLetter()
        }

        private fun parseFactor(): Double {
            if (eat('+'.code)) return parseFactor() // unary plus
            if (eat('-'.code)) return -parseFactor() // unary minus

            var x: Double
            val startPos = this.pos
            if (eat('('.code)) { // parentheses
                x = parseExpression()
                eat(')'.code)
            } else if (ch >= '0'.code && ch <= '9'.code || ch == '.'.code) { // numbers
                while (ch >= '0'.code && ch <= '9'.code || ch == '.'.code) nextChar()
                x = str.substring(startPos, this.pos).toDouble()
            } else if (ch >= 'a'.code && ch <= 'z'.code || ch >= 'A'.code && ch <= 'Z'.code) { // variables/functions
                while (ch >= 'a'.code && ch <= 'z'.code || ch >= 'A'.code && ch <= 'Z'.code) nextChar()
                val name = str.substring(startPos, this.pos).lowercase()
                if (name == "x") {
                    x = xVal
                } else if (name == "pi") {
                    x = Math.PI
                } else if (name == "e") {
                    x = Math.E
                } else {
                    if (eat('('.code)) {
                        val arg = parseExpression()
                        eat(')'.code)
                        x = when (name) {
                            "sin" -> sin(arg)
                            "cos" -> cos(arg)
                            "tan" -> tan(arg)
                            "log", "ln" -> ln(arg)
                            "log10" -> log10(arg)
                            "exp" -> exp(arg)
                            "sqrt" -> if (arg >= 0) sqrt(arg) else Double.NaN
                            "abs" -> abs(arg)
                            "sinh" -> sinh(arg)
                            "cosh" -> cosh(arg)
                            "tanh" -> tanh(arg)
                            "asin" -> asin(arg)
                            "acos" -> acos(arg)
                            "atan" -> atan(arg)
                            else -> throw RuntimeException("Unknown function: $name")
                        }
                    } else {
                        throw RuntimeException("Unknown identifier: $name")
                    }
                }
            } else {
                throw RuntimeException("Unexpected: " + ch.toChar())
            }

            if (eat('^'.code)) x = x.pow(parseFactor()) // exponentiation

            return x
        }
    }
}
