package com.example.data.database

import kotlinx.coroutines.flow.Flow

class EquationRepository(private val equationDao: EquationDao) {
    val allHistory: Flow<List<EquationHistory>> = equationDao.getAllHistory()

    suspend fun insert(equation: EquationHistory): Long {
        return equationDao.insert(equation)
    }

    suspend fun deleteById(id: Long) {
        equationDao.deleteById(id)
    }

    suspend fun clearAll() {
        equationDao.clearAll()
    }
}
