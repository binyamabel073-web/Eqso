package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF00E5FF),      // Cyber Cyan
    secondary = Color(0xFFE040FB),    // Neon Orchid / Purple
    tertiary = Color(0xFF8B008B),     // Dark Orchid Magenta
    background = Color(0xFF06060A),   // Deep cosmic dark slate
    surface = Color(0x13FFFFFF),      // Frosty white translucent glass
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White,
    outline = Color(0x40FFFFFF)       // Elegant white glass boundary
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF00838F),      // Vibrant Deep Cyan
    secondary = Color(0xFF8E24AA),    // Rich Deep Violet
    tertiary = Color(0xFFE1BEE7),     // Light Lavender
    background = Color(0xFFF0F3F8),   // Smooth liquid silver grey
    surface = Color(0x18000000),      // Frosted charcoal translucent glass
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = Color(0xFF0C0C12), // Dark slate text
    onSurface = Color(0xFF151520),    // Dark charcoal text
    outline = Color(0x28000000)       // Subtle charcoal glass boundary
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is available on Android 12+
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
