package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import com.example.ui.components.InteractiveGraph
import com.example.ui.components.ManimAnimationPlayer
import com.example.viewmodel.SolverViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: SolverViewModel,
    modifier: Modifier = Modifier
) {
    val query by viewModel.query.collectAsState()
    val engine by viewModel.engine.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val resultText by viewModel.resultText.collectAsState()
    val resultImageUrl by viewModel.resultImageUrl.collectAsState()
    val error by viewModel.error.collectAsState()

    val isGeneratingManim by viewModel.isGeneratingManim.collectAsState()
    val manimScriptResult by viewModel.manimScriptResult.collectAsState()
    val manimError by viewModel.manimError.collectAsState()

    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val scrollState = rememberScrollState()

    // Math Equation Presets
    val presets = listOf(
        "x^2 - 4x + 3",
        "sin(x) / x",
        "x^3 - 3*x",
        "cos(x) + sin(2*x)",
        "integrate x^2 dx",
        "derivative of ln(x)"
    )

    // Virtual Math Helper Keys
    val mathSymbols = listOf("x", "^", "(", ")", "+", "-", "*", "/", "sin(", "cos(", "tan(", "sqrt(", "pi")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Transparent)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        val isDark = MaterialTheme.colorScheme.onBackground == Color.White
        
        // Hero Branding Header
        val headerBg = if (isDark) {
            Brush.linearGradient(colors = listOf(Color(0x2EFFFFFF), Color(0x1000E5FF), Color(0x10E040FB)))
        } else {
            Brush.linearGradient(colors = listOf(Color(0x22000000), Color(0x0800838F), Color(0x088E24AA)))
        }
        val headerBorder = if (isDark) {
            Brush.linearGradient(colors = listOf(Color(0x5EFFFFFF), Color(0x2500E5FF), Color(0x25E040FB)))
        } else {
            Brush.linearGradient(colors = listOf(Color(0x22000000), Color(0x1500838F), Color(0x158E24AA)))
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(headerBg)
                .border(
                    width = 1.dp,
                    brush = headerBorder,
                    shape = RoundedCornerShape(24.dp)
                )
                .padding(24.dp)
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Functions,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Text(
                        text = "Wolfram Math Solver",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Solve and Visualize",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "A dual-engine visual solver powered by Wolfram Alpha, Gemini AI, and local math vector rendering.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
        }

        // Search Input Panel
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.outline,
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                        MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)
                    )
                )
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Engine Pill indicator
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Equation Solver",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "Engine: $engine",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                // Main input
                OutlinedTextField(
                    value = query,
                    onValueChange = { viewModel.updateQuery(it) },
                    placeholder = { Text("Enter expression e.g. x^2 - 4x + 3", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("equation_input_field"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(
                        onSearch = {
                            keyboardController?.hide()
                            viewModel.solve()
                        }
                    ),
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateQuery("") }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Clear text",
                                    tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.25f),
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.12f)
                    )
                )

                // Virtual helper keyboard row
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(mathSymbols) { symbol ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
                                .border(
                                    width = 1.dp,
                                    brush = Brush.verticalGradient(
                                        colors = listOf(
                                            MaterialTheme.colorScheme.outline,
                                            MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                                        )
                                    ),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .clickable {
                                    viewModel.updateQuery(query + symbol)
                                }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = symbol,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 13.sp
                            )
                        }
                    }
                }

                // Preset formulas row
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Presets",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                    
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(presets) { preset ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.surface)
                                    .border(
                                        width = 1.dp,
                                        brush = Brush.verticalGradient(
                                            colors = listOf(
                                                MaterialTheme.colorScheme.outline,
                                                MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                                            )
                                        ),
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .clickable {
                                        viewModel.updateQuery(preset)
                                    }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = preset,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Action Buttons Row (Calculate Solution & Generate Manim Animation)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Solve Button
                    Button(
                        onClick = {
                            keyboardController?.hide()
                            viewModel.solve()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("solve_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        shape = RoundedCornerShape(14.dp),
                        enabled = !isLoading && !isGeneratingManim
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                color = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Calculate,
                                    contentDescription = "Solve"
                                )
                                Text(
                                    text = "Calculate",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }

                    // Manim Animation Button
                    Button(
                        onClick = {
                            keyboardController?.hide()
                            viewModel.generateManimAnimation()
                        },
                        modifier = Modifier
                            .weight(1.5f)
                            .height(48.dp)
                            .testTag("manim_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary,
                            contentColor = MaterialTheme.colorScheme.onSecondary
                        ),
                        shape = RoundedCornerShape(14.dp),
                        enabled = !isLoading && !isGeneratingManim
                    ) {
                        if (isGeneratingManim) {
                            CircularProgressIndicator(
                                color = MaterialTheme.colorScheme.onSecondary,
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Movie,
                                    contentDescription = "Generate Manim Script"
                                )
                                Text(
                                    text = "Gen Manim Anim",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Manim Error Block
        AnimatedVisibility(
            visible = manimError != null,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            manimError?.let { err ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = "Error",
                            tint = Color(0xFFFF4D4D)
                        )
                        Text(
                            text = err,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFFFB3B3)
                        )
                    }
                }
            }
        }

        // Manim Script Result Block
        AnimatedVisibility(
            visible = !manimScriptResult.isNullOrBlank() && !isGeneratingManim,
            enter = fadeIn() + expandVertically()
        ) {
            manimScriptResult?.let { rawResult ->
                val (code, explanation) = remember(rawResult) { extractCodeAndText(rawResult) }
                var showSourceCode by remember { mutableStateOf(false) }

                val visualExpr = remember(query) {
                    var clean = query.trim()
                    if (clean.startsWith("solve ", ignoreCase = true)) {
                        clean = clean.substring(6).trim()
                    }
                    if (clean.contains("=")) {
                        clean = clean.split("=")[0].trim()
                    }
                    if (clean.isBlank()) "x^2 - 4x + 3" else clean
                }

                val solutionSteps = remember(explanation) {
                    explanation.split("\n")
                        .map { it.replace(Regex("^[-*#\\d.\\s]+"), "").trim() }
                        .filter { it.isNotBlank() && it.length > 5 }
                        .take(4)
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(
                        width = 1.dp,
                        brush = Brush.linearGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.outline,
                                MaterialTheme.colorScheme.secondary.copy(alpha = 0.25f),
                                MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f)
                            )
                        )
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Movie,
                                contentDescription = "Manim Animation",
                                tint = MaterialTheme.colorScheme.secondary
                            )
                            Text(
                                text = "Manim Math Animation",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Beautiful interactive on-device 60fps simulated player!
                        ManimAnimationPlayer(
                            expression = visualExpr,
                            solutionSteps = solutionSteps,
                            modifier = Modifier.fillMaxWidth()
                        )

                        if (explanation.isNotBlank()) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = explanation,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                                lineHeight = 20.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Collapsible Source Code section
                        HorizontalDivider(color = Color(0xFF232334))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showSourceCode = !showSourceCode }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Code,
                                    contentDescription = "Code",
                                    tint = Color(0xFF8A8A9E),
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "View Technical Python Source Code",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF8A8A9E)
                                )
                            }
                            Icon(
                                imageVector = if (showSourceCode) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = "Toggle Source Code",
                                tint = Color(0xFF8A8A9E)
                            )
                        }

                        AnimatedVisibility(
                            visible = showSourceCode,
                            enter = fadeIn() + expandVertically(),
                            exit = fadeOut() + shrinkVertically()
                        ) {
                            Column {
                                if (code.isNotBlank()) {
                                    // Code block header with Copy action
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                                            .background(Color(0xFF0C0C12))
                                            .padding(horizontal = 12.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(0xFFFF5F56))
                                            )
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(0xFFFFBD2E))
                                            )
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(0xFF27C93F))
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "math_animation.py",
                                                style = MaterialTheme.typography.bodySmall,
                                                fontFamily = FontFamily.Monospace,
                                                color = Color(0xFF8A8A9E)
                                            )
                                        }

                                        Button(
                                            onClick = {
                                                val clipboardManager = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                                val clip = android.content.ClipData.newPlainText("Manim Script", code)
                                                clipboardManager.setPrimaryClip(clip)
                                                android.widget.Toast.makeText(context, "Manim script copied to clipboard!", android.widget.Toast.LENGTH_SHORT).show()
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = Color(0xFF1E1E2A),
                                                contentColor = Color(0xFF00E5FF)
                                            ),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.height(28.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.ContentCopy,
                                                contentDescription = "Copy code",
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Copy", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    // Code text view
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp))
                                            .background(Color(0xFF08080C))
                                            .padding(12.dp)
                                    ) {
                                        Text(
                                            text = code,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 12.sp,
                                            color = Color(0xFF00E5FF),
                                            lineHeight = 18.sp,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))

                                    // Direct Google Colab creation row
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E2A)),
                                        border = BorderStroke(1.dp, Color(0xFF2C2C3E))
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Text(
                                                text = "How to run your animation:",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "1. Copy the code above.\n2. Click 'Open Google Colab' to create a blank notebook.\n3. Run '!pip install manim' in the first cell, then paste your code in a second cell to execute!",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color(0xFF8A8A9E),
                                                lineHeight = 16.sp
                                            )
                                            Spacer(modifier = Modifier.height(12.dp))
                                            Button(
                                                onClick = {
                                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://colab.research.google.com/#create=true"))
                                                    context.startActivity(intent)
                                                },
                                                modifier = Modifier.fillMaxWidth(),
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = Color(0xFFF57C00),
                                                    contentColor = Color.White
                                                ),
                                                shape = RoundedCornerShape(10.dp)
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Launch,
                                                        contentDescription = "Open Colab"
                                                    )
                                                    Text("Open Google Colab", fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Result / Interactive visualization outputs
        AnimatedVisibility(
            visible = error != null,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            error?.let { err ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0x33FF4D4D)),
                    border = BorderStroke(1.dp, Color(0x55FF4D4D))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = "Error",
                            tint = Color(0xFFFF4D4D)
                        )
                        Text(
                            text = err,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFFFB3B3)
                        )
                    }
                }
            }
        }

        // Text result block (for Wolfram text response / Gemini AI text response)
        AnimatedVisibility(
            visible = !resultText.isNullOrBlank() && !isLoading,
            enter = fadeIn() + expandVertically()
        ) {
            resultText?.let { text ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(
                        width = 1.dp,
                        brush = Brush.linearGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.outline,
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)
                            )
                        )
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (engine == "GEMINI") Icons.Default.Hub else Icons.Default.CheckCircleOutline,
                                contentDescription = "Result",
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = if (engine == "GEMINI") "Gemini AI Step Solution" else "Wolfram Solution Summary",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        // Selectable / Copyable text results
                        Text(
                            text = text,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                            lineHeight = 22.sp
                        )
                    }
                }
            }
        }

        // Visual chart result block (for Wolfram Alpha Simple API visual image)
        AnimatedVisibility(
            visible = !resultImageUrl.isNullOrBlank() && !isLoading,
            enter = fadeIn() + expandVertically()
        ) {
            resultImageUrl?.let { imageUrl ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(
                        width = 1.dp,
                        brush = Brush.linearGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.outline,
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)
                            )
                        )
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Image,
                                contentDescription = "Graph Output",
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Wolfram Visual Breakdown",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White) // matches wolfram simple bg set in client
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            SubcomposeAsyncImage(
                                model = imageUrl,
                                contentDescription = "Wolfram Alpha Result Details",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .wrapContentHeight(),
                                contentScale = ContentScale.FillWidth,
                                loading = {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(200.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        CircularProgressIndicator(
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                },
                                error = {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(24.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.SignalCellularConnectedNoInternet0Bar,
                                            contentDescription = null,
                                            tint = Color.Gray,
                                            modifier = Modifier.size(36.dp)
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = "Image failed to load. Check API key status or connection.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color.Gray,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }

        // Local Interactive Graphing Board
        // Show this whenever the equation contains a variable (or if the user explicitly wants to graph it locally!)
        val containsX = query.contains("x", ignoreCase = true)
        val shouldShowLocalGraph = (engine == "LOCAL" && query.isNotBlank()) || (containsX && !isLoading)
        
        AnimatedVisibility(
            visible = shouldShowLocalGraph,
            enter = fadeIn() + expandVertically()
        ) {
            InteractiveGraph(
                expression = query,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/**
 * Extracts python code from a Gemini markdown response and separates it from the descriptive text.
 */
private fun extractCodeAndText(fullText: String): Pair<String, String> {
    val startTag = "```python"
    val endTag = "```"
    var codeStartIndex = fullText.indexOf(startTag)
    var codeEndIndex = -1
    var code = ""
    var explanation = fullText

    if (codeStartIndex != -1) {
        val contentStart = codeStartIndex + startTag.length
        codeEndIndex = fullText.indexOf(endTag, contentStart)
        if (codeEndIndex != -1) {
            code = fullText.substring(contentStart, codeEndIndex).trim()
            val before = fullText.substring(0, codeStartIndex).trim()
            val after = fullText.substring(codeEndIndex + endTag.length).trim()
            explanation = listOf(before, after).filter { it.isNotEmpty() }.joinToString("\n\n")
        }
    } else {
        // Try fallback with just ```
        val fallbackStart = "```"
        codeStartIndex = fullText.indexOf(fallbackStart)
        if (codeStartIndex != -1) {
            val contentStart = codeStartIndex + fallbackStart.length
            codeEndIndex = fullText.indexOf(endTag, contentStart)
            if (codeEndIndex != -1) {
                code = fullText.substring(contentStart, codeEndIndex).trim()
                val before = fullText.substring(0, codeStartIndex).trim()
                val after = fullText.substring(codeEndIndex + endTag.length).trim()
                explanation = listOf(before, after).filter { it.isNotEmpty() }.joinToString("\n\n")
            }
        }
    }
    return Pair(code, explanation)
}

