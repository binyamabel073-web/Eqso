package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.plotter.LocalPlotter
import kotlin.math.roundToInt

@Composable
fun InteractiveGraph(
    expression: String,
    modifier: Modifier = Modifier
) {
    var rangeLimit by remember { mutableStateOf(10.0) } // Default x range is [-10, 10]
    
    val xMin = -rangeLimit
    val xMax = rangeLimit
    val yMin = -rangeLimit
    val yMax = rangeLimit

    val plotter = remember(expression) { LocalPlotter(expression) }
    
    var probedX by remember { mutableStateOf<Double?>(null) }
    var probedY by remember { mutableStateOf<Double?>(null) }
    var touchOffset by remember { mutableStateOf<Offset?>(null) }

    val density = LocalDensity.current
    val gridColor = Color(0xFF33333C)
    val axisColor = Color(0xFF7A8293)
    val functionColor = Color(0xFF00E5FF) // Cyber Cyan
    val probedColor = Color(0xFFFF2D55) // Neon Rose
    val labelColor = android.graphics.Color.GRAY

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xFF13131A))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Graph Title / Formula
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Local Plot Visualizer",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White
                )
                Text(
                    text = "y = ${expression.ifBlank { "0" }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF8A8A9E)
                )
            }
            
            // Zoom Controls
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(
                    onClick = { if (rangeLimit > 2.0) rangeLimit /= 2.0 },
                    colors = IconButtonDefaults.iconButtonColors(
                        containerColor = Color(0xFF23232E)
                    ),
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Zoom In",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
                
                IconButton(
                    onClick = { if (rangeLimit < 200.0) rangeLimit *= 2.0 },
                    colors = IconButtonDefaults.iconButtonColors(
                        containerColor = Color(0xFF23232E)
                    ),
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Remove,
                        contentDescription = "Zoom Out",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Coordinates Readout
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(40.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF1E1E28)),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (probedX != null && probedY != null && !probedY!!.isNaN()) {
                    Text(
                        text = "Probed Coordinate:",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF8A8A9E)
                    )
                    Text(
                        text = "X: ${"%.3f".format(probedX)}  |  Y: ${"%.3f".format(probedY)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = probedColor
                    )
                } else {
                    Text(
                        text = "Slide finger along graph to inspect values",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF5A5A6E)
                    )
                    Text(
                        text = "Scale: ±${rangeLimit.roundToInt()}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF00E5FF)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Main Drawing Area
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1.2f)
                .pointerInput(rangeLimit, expression) {
                    detectTapGestures(
                        onPress = { offset ->
                            val width = size.width.toDouble()
                            val mx = xMin + (offset.x / width) * (xMax - xMin)
                            val my = plotter.evaluate(mx)
                            if (!my.isNaN()) {
                                probedX = mx
                                probedY = my
                                touchOffset = offset
                            } else {
                                probedX = null
                                probedY = null
                                touchOffset = null
                            }
                        }
                    )
                }
                .pointerInput(rangeLimit, expression) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            val width = size.width.toDouble()
                            val mx = xMin + (offset.x / width) * (xMax - xMin)
                            val my = plotter.evaluate(mx)
                            if (!my.isNaN()) {
                                probedX = mx
                                probedY = my
                                touchOffset = offset
                            }
                        },
                        onDragEnd = {
                            probedX = null
                            probedY = null
                            touchOffset = null
                        },
                        onDragCancel = {
                            probedX = null
                            probedY = null
                            touchOffset = null
                        },
                        onDrag = { change, _ ->
                            val offset = change.position
                            val width = size.width.toDouble()
                            val mx = xMin + (offset.x / width) * (xMax - xMin)
                            val my = plotter.evaluate(mx)
                            if (!my.isNaN()) {
                                probedX = mx
                                probedY = my
                                touchOffset = offset
                            }
                        }
                    )
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height

                // Utility mapper functions
                fun toPixelX(mx: Double): Float {
                    return ((mx - xMin) / (xMax - xMin) * width).toFloat()
                }

                fun toPixelY(my: Double): Float {
                    return (height - (my - yMin) / (yMax - yMin) * height).toFloat()
                }

                // 1. Draw Grid Lines
                val step = rangeLimit / 5.0
                var currX = xMin
                while (currX <= xMax) {
                    val px = toPixelX(currX)
                    drawLine(gridColor, Offset(px, 0f), Offset(px, height), strokeWidth = 1f)
                    currX += step
                }

                var currY = yMin
                while (currY <= yMax) {
                    val py = toPixelY(currY)
                    drawLine(gridColor, Offset(0f, py), Offset(width, py), strokeWidth = 1f)
                    currY += step
                }

                // 2. Draw Main Axes (X & Y)
                val xAxisY = toPixelY(0.0)
                val yAxisX = toPixelX(0.0)

                // Draw X Axis
                if (xAxisY in 0.0f..height) {
                    drawLine(axisColor, Offset(0f, xAxisY), Offset(width, xAxisY), strokeWidth = 3f)
                }
                // Draw Y Axis
                if (yAxisX in 0.0f..width) {
                    drawLine(axisColor, Offset(yAxisX, 0f), Offset(yAxisX, height), strokeWidth = 3f)
                }

                // 3. Draw Axis Ticks & Labels
                drawContext.canvas.nativeCanvas.apply {
                    val paint = android.graphics.Paint().apply {
                        color = labelColor
                        textSize = with(density) { 10.sp.toPx() }
                        textAlign = android.graphics.Paint.Align.CENTER
                        isAntiAlias = true
                    }

                    // Ticks and numbers on X-axis
                    var xTick = xMin + step
                    while (xTick < xMax) {
                        if (xTick != 0.0) {
                            val px = toPixelX(xTick)
                            val py = if (xAxisY in 0.0f..height) xAxisY else height - 20f
                            // Tick line
                            drawLine(axisColor, Offset(px, py - 5f), Offset(px, py + 5f), strokeWidth = 2f)
                            // Text label
                            drawText(
                                "%.1f".format(xTick),
                                px,
                                py + 22f,
                                paint
                            )
                        }
                        xTick += step
                    }

                    // Ticks and numbers on Y-axis
                    var yTick = yMin + step
                    while (yTick < yMax) {
                        if (yTick != 0.0) {
                            val py = toPixelY(yTick)
                            val px = if (yAxisX in 0.0f..width) yAxisX else 20f
                            // Tick line
                            drawLine(axisColor, Offset(px - 5f, py), Offset(px + 5f, py), strokeWidth = 2f)
                            // Text label
                            paint.textAlign = android.graphics.Paint.Align.RIGHT
                            drawText(
                                "%.1f".format(yTick),
                                px - 10f,
                                py + 4f,
                                paint
                            )
                        }
                        yTick += step
                    }
                }

                // 4. Draw Function Path
                val path = Path()
                var firstPoint = true
                val stepSizePixels = 2f // calculate every 2 pixels for smooth drawing
                var pixelX = 0f

                while (pixelX <= width) {
                    val mx = xMin + (pixelX / width) * (xMax - xMin)
                    val my = plotter.evaluate(mx)

                    if (!my.isNaN() && my.isFinite()) {
                        val py = toPixelY(my)
                        if (py in -100f..(height + 100f)) { // Buffer boundary to avoid massive values
                            if (firstPoint) {
                                path.moveTo(pixelX, py)
                                firstPoint = false
                            } else {
                                path.lineTo(pixelX, py)
                            }
                        } else {
                            firstPoint = true // Break line if out of reasonable screen space
                        }
                    } else {
                        firstPoint = true // Break line on NaN
                    }

                    pixelX += stepSizePixels
                }

                drawPath(
                    path = path,
                    color = functionColor,
                    style = Stroke(width = 4f)
                )

                // 5. Draw Probe Cursor overlay if selected
                if (probedX != null && probedY != null && !probedY!!.isNaN()) {
                    val pX = toPixelX(probedX!!)
                    val pY = toPixelY(probedY!!)

                    if (pX in 0f..width && pY in 0f..height) {
                        // Horizontal dashed marker line
                        drawLine(
                            color = probedColor.copy(alpha = 0.4f),
                            start = Offset(0f, pY),
                            end = Offset(width, pY),
                            strokeWidth = 2f
                        )
                        // Vertical dashed marker line
                        drawLine(
                            color = probedColor.copy(alpha = 0.4f),
                            start = Offset(pX, 0f),
                            end = Offset(pX, height),
                            strokeWidth = 2f
                        )

                        // Outer glow dot
                        drawCircle(
                            color = probedColor.copy(alpha = 0.3f),
                            radius = 12f,
                            center = Offset(pX, pY)
                        )
                        // Inner dot
                        drawCircle(
                            color = probedColor,
                            radius = 6f,
                            center = Offset(pX, pY)
                        )
                    }
                }
            }
        }
    }
}
