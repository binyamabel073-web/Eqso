package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.plotter.LocalPlotter
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.*

@Composable
fun ManimAnimationPlayer(
    expression: String,
    solutionSteps: List<String> = emptyList(),
    modifier: Modifier = Modifier
) {
    var isPlaying by remember { mutableStateOf(true) }
    var speedMultiplier by remember { mutableStateOf(1f) } // 0.5f, 1f, 1.5f, 2f
    
    // Timeline animation value between 0f (start) and 1f (end)
    val animatableProgress = remember { Animatable(0f) }
    val coroutineScope = rememberCoroutineScope()
    
    // Auto Playback logic using Coroutines linked to standard state updates
    LaunchedEffect(isPlaying, speedMultiplier) {
        if (isPlaying) {
            val durationMs = (15000 / speedMultiplier).toInt()
            val remainingProgress = 1f - animatableProgress.value
            if (remainingProgress <= 0.01f) {
                animatableProgress.snapTo(0f)
            }
            animatableProgress.animateTo(
                targetValue = 1f,
                animationSpec = tween(
                    durationMillis = (durationMs * (1f - animatableProgress.value)).toInt(),
                    easing = LinearEasing
                )
            )
            isPlaying = false // Stop automatically when finished
        }
    }

    val progress = animatableProgress.value

    // Parsing step-by-step highlights depending on current frame timeline
    val currentStepIndex = remember(progress, solutionSteps) {
        if (solutionSteps.isEmpty()) -1
        else {
            val stepSize = 1f / (solutionSteps.size + 1)
            val index = (progress / stepSize).toInt() - 1
            index.coerceIn(-1, solutionSteps.lastIndex)
        }
    }

    val plotter = remember(expression) { LocalPlotter(expression) }
    val density = LocalDensity.current

    // Aesthetic Styling parameters
    val canvasBgColor = Color(0xFF0A0A0E)
    val mathLineColor = Color(0xFF00E5FF) // Cyan trace
    val axisColor = Color(0xFF5A6273)
    val stepLabelColor = Color(0xFFFF2D55) // Cyber magenta highlight
    val markerDotColor = Color(0xFFE040FB) // Violet highlight

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xFF13131A))
            .border(1.dp, Color(0xFF2C2C3E), RoundedCornerShape(24.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Player Header bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (isPlaying) Color(0xFF27C93F) else Color(0xFFFFBD2E))
                )
                Text(
                    text = "Manim Interactive Engine",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            
            Surface(
                color = Color(0xFF1E1E2A),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = "60 FPS RENDERER",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF00E5FF),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Main Manim Render Window
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1.6f) // 16:9 standard video viewport
                .clip(RoundedCornerShape(16.dp))
                .background(canvasBgColor)
                .border(1.dp, Color(0xFF1F1F2E), RoundedCornerShape(16.dp))
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height

                // Range limit representing screen viewport [-8, 8] on X, [-5, 5] on Y
                val xMin = -8.0
                val xMax = 8.0
                val yMin = -5.0
                val yMax = 5.0

                fun toPixelX(mx: Double): Float = ((mx - xMin) / (xMax - xMin) * width).toFloat()
                fun toPixelY(my: Double): Float = (height - (my - yMin) / (yMax - yMin) * height).toFloat()

                // Draw standard mathematical background grid
                val gridColor = Color(0xFF1A1A24)
                for (xVal in -8..8) {
                    val px = toPixelX(xVal.toDouble())
                    drawLine(gridColor, Offset(px, 0f), Offset(px, height), strokeWidth = 1f)
                }
                for (yVal in -5..5) {
                    val py = toPixelY(yVal.toDouble())
                    drawLine(gridColor, Offset(0f, py), Offset(width, py), strokeWidth = 1f)
                }

                // Draw central axes (origin drawing progress)
                val xAxisY = toPixelY(0.0)
                val yAxisX = toPixelX(0.0)

                // Animate axes opening up from center outward
                val axisAnimProgress = (progress * 4f).coerceAtMost(1f)
                val xAxisHalfWidth = (width / 2) * axisAnimProgress
                val yAxisHalfHeight = (height / 2) * axisAnimProgress

                drawLine(
                    color = axisColor,
                    start = Offset(width / 2 - xAxisHalfWidth, xAxisY),
                    end = Offset(width / 2 + xAxisHalfWidth, xAxisY),
                    strokeWidth = 2f
                )
                drawLine(
                    color = axisColor,
                    start = Offset(yAxisX, height / 2 - yAxisHalfHeight),
                    end = Offset(yAxisX, height / 2 + yAxisHalfHeight),
                    strokeWidth = 2f
                )

                // Draw Axis tick markers if axes are completed
                if (axisAnimProgress >= 0.9f) {
                    // X-axis marks
                    for (xVal in -7..7) {
                        if (xVal != 0) {
                            val px = toPixelX(xVal.toDouble())
                            drawLine(axisColor, Offset(px, xAxisY - 4f), Offset(px, xAxisY + 4f), strokeWidth = 1.5f)
                        }
                    }
                    // Y-axis marks
                    for (yVal in -4..4) {
                        if (yVal != 0) {
                            val py = toPixelY(yVal.toDouble())
                            drawLine(axisColor, Offset(yAxisX - 4f, py), Offset(yAxisX + 4f, py), strokeWidth = 1.5f)
                        }
                    }
                }

                // Draw Animated Function Curve
                // The curve draws itself from left to right as the animation progress advances (from 0.1 to 0.9)
                val graphAnimProgress = ((progress - 0.15f) / 0.7f).coerceIn(0f, 1f)
                if (graphAnimProgress > 0f) {
                    val path = Path()
                    var firstPoint = true
                    
                    // We step in x to create the lines up to our animated threshold
                    val activeMaxX = xMin + (xMax - xMin) * graphAnimProgress
                    val pixelStep = 2f
                    var px = 0f
                    
                    while (px <= width * graphAnimProgress) {
                        val mx = xMin + (px / width) * (xMax - xMin)
                        val my = plotter.evaluate(mx)
                        if (!my.isNaN() && my.isFinite()) {
                            val py = toPixelY(my)
                            if (py in -100f..(height + 100f)) {
                                if (firstPoint) {
                                    path.moveTo(px, py)
                                    firstPoint = false
                                } else {
                                    path.lineTo(px, py)
                                }
                            } else {
                                firstPoint = true
                            }
                        } else {
                            firstPoint = true
                        }
                        px += pixelStep
                    }

                    drawPath(
                        path = path,
                        color = mathLineColor,
                        style = Stroke(width = 4f)
                    )

                    // Draw moving tracing vector or derivative point
                    // Let's place a moving dot on the leading edge of the drawing graph
                    val currentX = xMin + (xMax - xMin) * graphAnimProgress
                    val currentY = plotter.evaluate(currentX)
                    if (!currentY.isNaN() && currentY.isFinite()) {
                        val pX = toPixelX(currentX)
                        val pY = toPixelY(currentY)

                        // Outer glowing circle
                        drawCircle(
                            color = markerDotColor.copy(alpha = 0.35f),
                            radius = 14f,
                            center = Offset(pX, pY)
                        )
                        // Core dot
                        drawCircle(
                            color = markerDotColor,
                            radius = 7f,
                            center = Offset(pX, pY)
                        )

                        // Animated tangent line if progress is well advanced
                        if (graphAnimProgress > 0.2f && graphAnimProgress < 0.95f) {
                            // Find slope numerically
                            val delta = 0.01
                            val y2 = plotter.evaluate(currentX + delta)
                            val slope = (y2 - currentY) / delta
                            
                            if (slope.isFinite()) {
                                // tangent line: y - currentY = slope * (x - currentX)
                                // let's plot a short segment [-1.5, +1.5] around currentX
                                val tanX1 = currentX - 1.5
                                val tanY1 = currentY - 1.5 * slope
                                val tanX2 = currentX + 1.5
                                val tanY2 = currentY + 1.5 * slope

                                drawLine(
                                    color = Color(0xFFFFD54F), // Amber tangent line
                                    start = Offset(toPixelX(tanX1), toPixelY(tanY1)),
                                    end = Offset(toPixelX(tanX2), toPixelY(tanY2)),
                                    strokeWidth = 2f
                                )
                            }
                        }
                    }
                }

                // Render dynamic formula text inside the video viewport
                drawContext.canvas.nativeCanvas.apply {
                    val textPaint = android.graphics.Paint().apply {
                        color = android.graphics.Color.WHITE
                        textSize = with(density) { 14.sp.toPx() }
                        typeface = android.graphics.Typeface.MONOSPACE
                        isAntiAlias = true
                    }

                    drawText(
                        "Formula: y = $expression",
                        30f,
                        45f,
                        textPaint
                    )

                    // Draw rendering credits watermark in the corner
                    textPaint.color = android.graphics.Color.DKGRAY
                    textPaint.textSize = with(density) { 9.sp.toPx() }
                    drawText(
                        "Manim CE Vector Simulator",
                        width - 180f,
                        height - 20f,
                        textPaint
                    )
                }
            }
        }

        // Dynamic Step explanation block located below the viewport to ensure unobstructed viewing
        AnimatedVisibility(
            visible = currentStepIndex >= 0 && currentStepIndex < solutionSteps.size,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically(),
            modifier = Modifier.fillMaxWidth()
        ) {
            val idx = currentStepIndex
            if (idx >= 0 && idx < solutionSteps.size) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF1E1E2A))
                        .border(1.dp, stepLabelColor.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "EXPLANATION / STEP ${idx + 1}:",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = stepLabelColor,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = solutionSteps[idx],
                            fontSize = 12.sp,
                            color = Color.White,
                            lineHeight = 16.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Progress Scrub Slider Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = formatDuration(progress * 15f),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF8A8A9E)
            )

            Slider(
                value = progress,
                onValueChange = { newValue ->
                    isPlaying = false
                    coroutineScope.launch {
                        animatableProgress.snapTo(newValue)
                    }
                },
                modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(
                    activeTrackColor = Color(0xFF00E5FF),
                    inactiveTrackColor = Color(0xFF232334),
                    thumbColor = Color(0xFFE040FB)
                )
            )

            Text(
                text = "0:15",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF8A8A9E)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Interactive Player Transport Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Speed control
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf(0.5f, 1f, 1.5f, 2f).forEach { speed ->
                    val isSelected = speedMultiplier == speed
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) Color(0xFFE040FB) else Color(0xFF1E1E2A))
                            .clickable { speedMultiplier = speed }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${speed}x",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else Color(0xFF8A8A9E)
                        )
                    }
                }
            }

            // Central buttons (Play, Pause, Restart)
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Restart button
                IconButton(
                    onClick = {
                        isPlaying = false
                        coroutineScope.launch {
                            animatableProgress.snapTo(0f)
                            isPlaying = true
                        }
                    },
                    modifier = Modifier.size(36.dp),
                    colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF1E1E2A))
                ) {
                    Icon(
                        imageVector = Icons.Default.Replay,
                        contentDescription = "Restart Animation",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }

                // Play / Pause toggle
                IconButton(
                    onClick = { isPlaying = !isPlaying },
                    modifier = Modifier.size(48.dp),
                    colors = IconButtonDefaults.iconButtonColors(
                        containerColor = if (isPlaying) Color(0xFFFF2D55) else Color(0xFF00E5FF)
                    )
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = Color.Black,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            // Loop indicator
            Text(
                text = "LOOPING ON",
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF8A8A9E),
                letterSpacing = 1.sp
            )
        }
    }
}

private fun formatDuration(seconds: Float): String {
    val secInt = seconds.toInt().coerceIn(0, 15)
    val hundredths = ((seconds - secInt) * 100).toInt().coerceIn(0, 99)
    return "0:%02d.%02d".format(secInt, hundredths)
}
