package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.MainScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.SolverViewModel

import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.drawBehind
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Enable Edge-to-Edge full bleed layout support
        enableEdgeToEdge()
        setContent {
            val viewModel: SolverViewModel = viewModel()
            val isDarkTheme by viewModel.isDarkTheme.collectAsState()
            
            MyApplicationTheme(darkTheme = isDarkTheme) {
                var currentScreen by remember { mutableStateOf("solver") }

                val glassBorderBrush = if (isDarkTheme) {
                    Brush.linearGradient(colors = listOf(Color(0x3BFFFFFF), Color(0x10FFFFFF)))
                } else {
                    Brush.linearGradient(colors = listOf(Color(0x22000000), Color(0x08000000)))
                }
                val bottomBarContainerColor = if (isDarkTheme) Color(0x1A000000) else Color(0x0F000000)
                
                val selectedTextColor = if (isDarkTheme) Color(0xFF00E5FF) else Color(0xFF00838F)
                val unselectedColor = if (isDarkTheme) Color(0x99FFFFFF) else Color(0x99000000)
                val indicatorColor = if (isDarkTheme) Color(0xFF00E5FF) else Color(0xFFB2EBF2)

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = Color.Transparent, // Let the liquid background shine through
                    bottomBar = {
                        NavigationBar(
                            modifier = Modifier
                                .navigationBarsPadding() // Ensures safety on modern Android gesture pill interfaces
                                .padding(start = 16.dp, end = 16.dp, bottom = 12.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .border(
                                    width = 1.dp,
                                    brush = glassBorderBrush,
                                    shape = RoundedCornerShape(24.dp)
                                )
                                .fillMaxWidth()
                                .testTag("bottom_navigation_bar"),
                            containerColor = bottomBarContainerColor, // Frosted dynamic glass
                            tonalElevation = 0.dp
                        ) {
                            NavigationBarItem(
                                selected = currentScreen == "solver",
                                onClick = { currentScreen = "solver" },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.Calculate,
                                        contentDescription = "Solver Workspace"
                                    )
                                },
                                label = { Text("Solver", fontWeight = FontWeight.Bold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = if (isDarkTheme) Color.Black else Color.White,
                                    selectedTextColor = selectedTextColor,
                                    unselectedIconColor = unselectedColor,
                                    unselectedTextColor = unselectedColor,
                                    indicatorColor = indicatorColor
                                ),
                                modifier = Modifier.testTag("nav_solver")
                            )

                            NavigationBarItem(
                                selected = currentScreen == "history",
                                onClick = { currentScreen = "history" },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.History,
                                        contentDescription = "Saved History Logs"
                                    )
                                },
                                label = { Text("History", fontWeight = FontWeight.Bold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = if (isDarkTheme) Color.Black else Color.White,
                                    selectedTextColor = selectedTextColor,
                                    unselectedIconColor = unselectedColor,
                                    unselectedTextColor = unselectedColor,
                                    indicatorColor = indicatorColor
                                ),
                                modifier = Modifier.testTag("nav_history")
                            )

                            NavigationBarItem(
                                selected = currentScreen == "settings",
                                onClick = { currentScreen = "settings" },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.Settings,
                                        contentDescription = "Settings"
                                    )
                                },
                                label = { Text("Settings", fontWeight = FontWeight.Bold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = if (isDarkTheme) Color.Black else Color.White,
                                    selectedTextColor = selectedTextColor,
                                    unselectedIconColor = unselectedColor,
                                    unselectedTextColor = unselectedColor,
                                    indicatorColor = indicatorColor
                                ),
                                modifier = Modifier.testTag("nav_settings")
                            )
                        }
                    }
                ) { innerPadding ->
                    // Animated content transition for a premium fluid UX
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .drawBehind {
                                if (isDarkTheme) {
                                    // Background base
                                    drawRect(color = Color(0xFF06060A))
                                    
                                    // Soft dynamic liquid magenta glow in top right
                                    drawCircle(
                                        brush = Brush.radialGradient(
                                            colors = listOf(Color(0xFF8B008B).copy(alpha = 0.22f), Color.Transparent),
                                            center = androidx.compose.ui.geometry.Offset(size.width * 0.95f, size.height * 0.12f),
                                            radius = size.width * 0.9f
                                        )
                                    )
                                    
                                    // Soft dynamic liquid cyan glow in bottom left
                                    drawCircle(
                                        brush = Brush.radialGradient(
                                            colors = listOf(Color(0xFF00BFFF).copy(alpha = 0.18f), Color.Transparent),
                                            center = androidx.compose.ui.geometry.Offset(size.width * 0.05f, size.height * 0.88f),
                                            radius = size.width * 0.9f
                                        )
                                    )
                                    
                                    // Soft blue/indigo neon glow in center
                                    drawCircle(
                                        brush = Brush.radialGradient(
                                            colors = listOf(Color(0xFF5E00FF).copy(alpha = 0.15f), Color.Transparent),
                                            center = androidx.compose.ui.geometry.Offset(size.width * 0.5f, size.height * 0.5f),
                                            radius = size.width * 0.7f
                                        )
                                    )
                                } else {
                                    // Light liquid background
                                    drawRect(color = Color(0xFFF0F3F8))
                                    
                                    // Soft lavender top-right glow
                                    drawCircle(
                                        brush = Brush.radialGradient(
                                            colors = listOf(Color(0xFFE040FB).copy(alpha = 0.12f), Color.Transparent),
                                            center = androidx.compose.ui.geometry.Offset(size.width * 0.95f, size.height * 0.12f),
                                            radius = size.width * 0.9f
                                        )
                                    )
                                    
                                    // Soft sky-blue bottom-left glow
                                    drawCircle(
                                        brush = Brush.radialGradient(
                                            colors = listOf(Color(0xFF00BFFF).copy(alpha = 0.12f), Color.Transparent),
                                            center = androidx.compose.ui.geometry.Offset(size.width * 0.05f, size.height * 0.88f),
                                            radius = size.width * 0.9f
                                        )
                                    )
                                    
                                    // Soft lilac center glow
                                    drawCircle(
                                        brush = Brush.radialGradient(
                                            colors = listOf(Color(0xFF8A2BE2).copy(alpha = 0.08f), Color.Transparent),
                                            center = androidx.compose.ui.geometry.Offset(size.width * 0.5f, size.height * 0.5f),
                                            radius = size.width * 0.7f
                                        )
                                    )
                                }
                            }
                            .padding(
                                top = innerPadding.calculateTopPadding(),
                                bottom = innerPadding.calculateBottomPadding()
                            )
                    ) {
                        when (currentScreen) {
                            "solver" -> MainScreen(viewModel = viewModel)
                            "history" -> HistoryScreen(
                                viewModel = viewModel,
                                onSelectEquation = { selectedFormula ->
                                    viewModel.updateQuery(selectedFormula)
                                    currentScreen = "solver"
                                }
                            )
                            "settings" -> SettingsScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}
