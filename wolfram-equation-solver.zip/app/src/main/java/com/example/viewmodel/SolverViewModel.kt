package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.database.EquationHistory
import com.example.data.database.EquationRepository
import com.example.data.network.GeminiSolver
import com.example.data.network.WolframAlphaClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SolverViewModel(application: Application) : AndroidViewModel(application) {

    private val sharedPrefs = application.getSharedPreferences("wolfram_solver_prefs", Context.MODE_PRIVATE)
    private val database = AppDatabase.getDatabase(application)
    private val repository = EquationRepository(database.equationDao())

    // UI Input State
    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    // Configuration preferences
    private val _appId = MutableStateFlow(sharedPrefs.getString("wolfram_app_id", "") ?: "")
    val appId: StateFlow<String> = _appId.asStateFlow()

    val isSecretAppIdActive: Boolean
        get() {
            val configVal = com.example.BuildConfig.WOLFRAM_APP_ID
            return _appId.value.isBlank() && configVal.isNotBlank() && configVal != "MY_WOLFRAM_APP_ID"
        }

    private val _engine = MutableStateFlow(sharedPrefs.getString("solver_engine", "LOCAL") ?: "LOCAL")
    val engine: StateFlow<String> = _engine.asStateFlow()

    private val _isDarkTheme = MutableStateFlow(sharedPrefs.getBoolean("is_dark_theme", true))
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    // Solver results states
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _resultText = MutableStateFlow<String?>(null)
    val resultText: StateFlow<String?> = _resultText.asStateFlow()

    private val _resultImageUrl = MutableStateFlow<String?>(null)
    val resultImageUrl: StateFlow<String?> = _resultImageUrl.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    // Manim Script generation states
    private val _isGeneratingManim = MutableStateFlow(false)
    val isGeneratingManim: StateFlow<Boolean> = _isGeneratingManim.asStateFlow()

    private val _manimScriptResult = MutableStateFlow<String?>(null)
    val manimScriptResult: StateFlow<String?> = _manimScriptResult.asStateFlow()

    private val _manimError = MutableStateFlow<String?>(null)
    val manimError: StateFlow<String?> = _manimError.asStateFlow()

    // Database flow observed in UI
    val historyList: StateFlow<List<EquationHistory>> = repository.allHistory
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun updateQuery(newQuery: String) {
        _query.value = newQuery
    }

    fun saveAppId(newAppId: String) {
        _appId.value = newAppId
        sharedPrefs.edit().putString("wolfram_app_id", newAppId).apply()
        // If the user added an AppID, we can automatically suggest switching to WOLFRAM if it was in LOCAL
        if (newAppId.isNotBlank() && _engine.value == "LOCAL") {
            setEngine("WOLFRAM")
        }
    }

    fun setEngine(newEngine: String) {
        _engine.value = newEngine
        sharedPrefs.edit().putString("solver_engine", newEngine).apply()
    }

    fun setDarkTheme(enabled: Boolean) {
        _isDarkTheme.value = enabled
        sharedPrefs.edit().putBoolean("is_dark_theme", enabled).apply()
    }

    fun clearResults() {
        _resultText.value = null
        _resultImageUrl.value = null
        _error.value = null
        _manimScriptResult.value = null
        _manimError.value = null
    }

    fun generateManimAnimation() {
        val currentQuery = _query.value.trim()
        if (currentQuery.isBlank()) {
            _manimError.value = "Please enter an equation or expression first."
            return
        }

        viewModelScope.launch {
            _isGeneratingManim.value = true
            _manimError.value = null
            _manimScriptResult.value = null

            try {
                val result = GeminiSolver.generateManimScript(currentQuery)
                if (result.contains("Gemini API Key is not set")) {
                    _manimError.value = result
                } else {
                    _manimScriptResult.value = result
                }
            } catch (e: Exception) {
                _manimError.value = "Failed to generate animation: ${e.localizedMessage}"
            } finally {
                _isGeneratingManim.value = false
            }
        }
    }

    fun solve() {
        val currentQuery = _query.value.trim()
        if (currentQuery.isBlank()) {
            _error.value = "Please enter an equation or expression first."
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _error.value = null
            _resultText.value = null
            _resultImageUrl.value = null
            _manimScriptResult.value = null
            _manimError.value = null

            val selectedEngine = _engine.value
            var finalResultText: String? = null
            var finalResultImageUrl: String? = null

            try {
                when (selectedEngine) {
                    "WOLFRAM" -> {
                        var currentAppId = _appId.value.trim()
                        if (currentAppId.isBlank()) {
                            val configAppId = com.example.BuildConfig.WOLFRAM_APP_ID
                            if (configAppId.isNotBlank() && configAppId != "MY_WOLFRAM_APP_ID") {
                                currentAppId = configAppId
                            }
                        }

                        if (currentAppId.isBlank()) {
                            _error.value = "Wolfram Alpha App ID is required. Please configure your App ID in the Settings tab."
                            _isLoading.value = false
                            return@launch
                        }

                        // 1. Fetch text answer
                        val textAns = WolframAlphaClient.getShortAnswer(currentQuery, currentAppId)
                        if (textAns.startsWith("Invalid App ID") || 
                            textAns.startsWith("Unauthorized App ID") ||
                            textAns.startsWith("Wolfram Alpha returned an error: Code 403") ||
                            textAns.startsWith("Wolfram Alpha returned an error: Code 401")) {
                            _error.value = "Invalid or Unauthorized App ID. Please verify your App ID in the Settings tab."
                            _isLoading.value = false
                            return@launch
                        }
                        
                        finalResultText = textAns

                        // 2. Fetch the URL for the rich visual image
                        finalResultImageUrl = WolframAlphaClient.getSimpleImageUrl(currentQuery, currentAppId)
                    }
                    "GEMINI" -> {
                        val geminiAns = GeminiSolver.solveEquation(currentQuery)
                        if (geminiAns.startsWith("Gemini API Key is not set")) {
                            _error.value = geminiAns
                            _isLoading.value = false
                            return@launch
                        }
                        finalResultText = geminiAns
                    }
                    "LOCAL" -> {
                        // For LOCAL engine, we plot the visual graph locally
                        // and we can also evaluate basic numeric equations
                        finalResultText = "Plotted on local graph visualizer below. Modify coordinates and touch the graph to explore curves."
                    }
                }

                // Update UI State
                _resultText.value = finalResultText
                _resultImageUrl.value = finalResultImageUrl

                // Save to history
                repository.insert(
                    EquationHistory(
                        query = currentQuery,
                        engine = selectedEngine,
                        resultText = finalResultText,
                        resultImageUrl = finalResultImageUrl
                    )
                )

            } catch (e: Exception) {
                _error.value = "An error occurred: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch {
            repository.deleteById(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAll()
        }
    }
}
